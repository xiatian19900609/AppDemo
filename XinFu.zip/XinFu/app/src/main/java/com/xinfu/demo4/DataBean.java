package com.xinfu.demo4;

public class DataBean {
    public String T_name;
    public String U_name;
    public String face;
    public String Id;
    public String Addtime;
    public String Title;
    public String Content;
    public String time;
    public String Pic;
}