package com.xinfu.demo7;

import android.graphics.PathMeasure;
import android.view.View;

/**
 * Created by xiatian on 2016/9/3.
 */
public class AnimationBean {
    public View tv;
    public PathMeasure mPathMeasure;
}
