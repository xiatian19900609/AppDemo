package com.xinfu.demo4;

/**
 * <pre>
 *     author : xiatian
 *     time   : 2017/05/09
 *     desc   :
 * </pre>
 */
public interface FilterCallBack {
    void onFilterFinish(String type);
}
