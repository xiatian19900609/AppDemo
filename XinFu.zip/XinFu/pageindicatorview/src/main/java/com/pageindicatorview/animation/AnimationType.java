package com.pageindicatorview.animation;

public enum AnimationType {NONE, COLOR, SCALE, WORM, SLIDE, FILL, THIN_WORM, DROP, SWAP,DRAG_WORM}
