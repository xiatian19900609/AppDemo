package com.pageindicatorview;

public enum RtlMode {On, Off, Auto}