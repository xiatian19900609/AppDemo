package com.pageindicatorview;

public enum Orientation {HORIZONTAL, VERTICAL}
